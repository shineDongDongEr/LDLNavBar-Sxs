//
//  ViewController.m
//  NavBarDemo
//
//  Created by edz on 2020/4/16.
//  Copyright © 2020 edz. All rights reserved.
//

#import "ViewController.h"
#import "UINavigationBar+SXS.h"
#import "FirstViewController.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"
#import "FourthViewController.h"

@interface ViewController ()

@end

@implementation ViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"导航栏白色";
    self.view.backgroundColor = UIColor.yellowColor;
    [self.navigationController.navigationBar setTitleColor:UIColor.redColor font:[UIFont boldSystemFontOfSize:23]];
    [self.navigationController.navigationBar setBackColor:UIColor.whiteColor];
    [self.navigationController.navigationBar setBackImageWithImageName:@"返回黑色"];

}

- (IBAction)jump3:(id)sender {
}

- (IBAction)jump4:(id)sender {
}

@end

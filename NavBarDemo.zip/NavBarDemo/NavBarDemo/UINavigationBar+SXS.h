//
//  UINavigationBar+SXS.h
//  sxsiosapp
//
//  Created by Laidongling on 2020/4/10.
//  Copyright © 2020 mshare. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UINavigationBar (SXS)

/// 设置导航条没有下划线
-(void)setNoLine;

/// 设置导航栏背景色（注：设置透明请使用setBackClear方法，自带去下划线）
/// @param backColor 颜色
- (void)setBackColor:(UIColor *)backColor;

/// 设置导航栏透明（自带去下划线）
- (void)setBackClear;

/// 默认恢复成系统的颜色和下划线
- (void)resetBack;

/// 设置导航条标题颜色和字号
- (void)setTitleColor:(UIColor *)titleColor font:(UIFont *)font;

/// 设置自定义的返回按钮
/// @param imageName 返回按钮图片名字
- (void)setBackImageWithImageName:(NSString *)imageName;

@end

NS_ASSUME_NONNULL_END

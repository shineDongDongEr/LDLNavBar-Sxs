//
//  ThirdViewController.m
//  NavBarDemo
//
//  Created by edz on 2020/4/17.
//  Copyright © 2020 edz. All rights reserved.
//

#import "ThirdViewController.h"

@interface ThirdViewController ()

@end

@implementation ThirdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.orangeColor;
    self.title = @"导航栏透明";
//    [self.navigationController.navigationBar setBackImageWithImageName:@"返回系统蓝色"];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar setBackClear];
 
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.navigationController.navigationBar setTitleColor:UIColor.yellowColor font:[UIFont boldSystemFontOfSize:18]];
    [self.navigationController.navigationBar setBackColor:UIColor.purpleColor];
}


@end

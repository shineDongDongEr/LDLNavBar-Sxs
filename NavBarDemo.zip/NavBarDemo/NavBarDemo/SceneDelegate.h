//
//  SceneDelegate.h
//  NavBarDemo
//
//  Created by edz on 2020/4/16.
//  Copyright © 2020 edz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end


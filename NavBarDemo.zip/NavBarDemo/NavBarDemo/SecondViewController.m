//
//  SecondViewController.m
//  NavBarDemo
//
//  Created by edz on 2020/4/17.
//  Copyright © 2020 edz. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"导航栏紫色";
    self.view.backgroundColor = UIColor.blueColor;

}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar setTitleColor:UIColor.yellowColor font:[UIFont boldSystemFontOfSize:18]];
    [self.navigationController.navigationBar setBackColor:UIColor.purpleColor];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.navigationController.navigationBar setTitleColor:UIColor.redColor font:[UIFont boldSystemFontOfSize:23]];
    [self.navigationController.navigationBar setBackColor:UIColor.whiteColor];
}


@end

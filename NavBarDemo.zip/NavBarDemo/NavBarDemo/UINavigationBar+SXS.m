//
//  UINavigationBar+SXS.m
//  sxsiosapp
//
//  Created by Laidongling on 2020/4/10.
//  Copyright © 2020 mshare. All rights reserved.
//

#import "UINavigationBar+SXS.h"

@implementation UINavigationBar (SXS)

-(void)setNoLine
{
    if (@available(iOS 13.0, *)) {
        self.standardAppearance.shadowColor = [UIColor clearColor];
      } else {
          if (@available(iOS 10.0, *))
          {
              [self getLineHidden:YES];
          }else
          {
              self.shadowImage = [UIImage new];
          }
      }
}

- (void)setBackColor:(UIColor *)backColor
{
    if (@available(iOS 13.0, *))
    {
        [self.standardAppearance configureWithOpaqueBackground];
        [self.standardAppearance setBackgroundColor:backColor];
        [self.standardAppearance setBackgroundImage:nil];
    }else
    {
        [self setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
        [self setBarTintColor:backColor];
    }
}

- (void)setBackClear
{
    if (@available(iOS 13.0, *))
    {
        [self.standardAppearance configureWithTransparentBackground];
        self.standardAppearance.shadowColor = [UIColor clearColor];
    }else
    {
        [self setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
        if (@available(iOS 10.0, *))
        {
            [self getLineHidden:YES];
        }else
        {
            self.shadowImage = [UIImage new];
        }
    }
}

- (void)resetBack
{
    if (@available(iOS 13.0, *))
    {
        [self.standardAppearance configureWithDefaultBackground];
        self.standardAppearance.shadowImage = nil;
    }else
    {
        [self setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
        
        if (@available(iOS 10.0, *))
          {
              [self getLineHidden:NO];
          }else
          {
               self.shadowImage = nil;
          }
    }
}

- (void)getLineHidden:(BOOL)hidden
{
    if ([self respondsToSelector:@selector( setBackgroundImage:forBarMetrics:)])
        {
            NSArray *list=self.subviews;

            for (id obj in list)
            {
                UIView *view = (UIView*)obj;
                for (id obj2 in view.subviews) {

                    if ([obj2 isKindOfClass:[UIImageView class]])
                    {
                        UIImageView *image =  (UIImageView*)obj2;
                        image.hidden = hidden;
                    }
                }
            }
        }
}

- (void)setTitleColor:(UIColor *)titleColor font:(UIFont *)font
{
    //文字颜色
      if (@available(iOS 13.0, *))
      {
          [self.standardAppearance setTitleTextAttributes:@{NSFontAttributeName:font , NSForegroundColorAttributeName:titleColor}];
      }else
      {
          [self setTitleTextAttributes:@{NSFontAttributeName:font , NSForegroundColorAttributeName:titleColor}];
      }
}

- (void)setBackImageWithImageName:(NSString *)imageName
{
    UIImage *image = [UIImage imageNamed:imageName];
    image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    if (@available(iOS 13.0, *))
    {
        [self.standardAppearance setBackIndicatorImage:image transitionMaskImage:image];
    }else
    {
        self.backIndicatorImage = image;
        self.backIndicatorTransitionMaskImage = image;
    }
}

@end

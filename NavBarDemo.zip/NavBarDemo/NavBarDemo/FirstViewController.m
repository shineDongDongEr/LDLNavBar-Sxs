//
//  FirstViewController.m
//  NavBarDemo
//
//  Created by edz on 2020/4/17.
//  Copyright © 2020 edz. All rights reserved.
//

#import "FirstViewController.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"导航栏透明";
    self.view.backgroundColor = UIColor.greenColor;
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar setBackClear];
    [self.navigationController.navigationBar setTitleColor:[UIColor redColor] font:[UIFont systemFontOfSize:15]];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.navigationController.navigationBar setTitleColor:UIColor.redColor font:[UIFont boldSystemFontOfSize:23]];
    [self.navigationController.navigationBar setBackColor:UIColor.whiteColor];
}

@end

//
//  FourthViewController.m
//  NavBarDemo
//
//  Created by edz on 2020/4/17.
//  Copyright © 2020 edz. All rights reserved.
//

#import "FourthViewController.h"

@interface FourthViewController ()

@end

@implementation FourthViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"系统导航条";
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar setTitleColor:[UIColor blackColor] font:[UIFont systemFontOfSize:16]];
    [self.navigationController.navigationBar resetBack];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
   [self.navigationController.navigationBar setTitleColor:UIColor.yellowColor font:[UIFont boldSystemFontOfSize:18]];
   [self.navigationController.navigationBar setBackColor:UIColor.purpleColor];
}


@end
